(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_aed12c01._.js",
  "static/chunks/src_b7ac0b58._.js",
  "static/chunks/node_modules_swiper_acd668f0._.css"
],
    source: "dynamic"
});
