(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_45b234b0._.js",
  "static/chunks/node_modules_react-photo-view_dist_react-photo-view_829d5604.css"
],
    source: "dynamic"
});
