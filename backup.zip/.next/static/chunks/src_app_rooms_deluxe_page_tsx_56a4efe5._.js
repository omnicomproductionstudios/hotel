(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_ae3338dc._.js",
  "static/chunks/src_32c66e3a._.js",
  "static/chunks/node_modules_3a20a209._.css"
],
    source: "dynamic"
});
