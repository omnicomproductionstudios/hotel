(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__b881425d._.css",
  "static/chunks/node_modules_bootstrap_dist_js_bootstrap_bundle_min_4cf9e9c8.js",
  "static/chunks/node_modules_1a1c5952._.js",
  "static/chunks/src_components_23cb0569._.js"
],
    source: "dynamic"
});
