(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_components_90b12261._.js",
  "static/chunks/node_modules_swiper_a36f9494._.js",
  "static/chunks/node_modules_motion-dom_dist_es_ed5d7820._.js",
  "static/chunks/node_modules_framer-motion_dist_es_ad9bbf4d._.js",
  "static/chunks/node_modules_0e9a95ed._.js",
  "static/chunks/node_modules_swiper_b167c7bf._.css"
],
    source: "dynamic"
});
