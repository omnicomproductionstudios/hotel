"use client";

export default function Loading() {
  return (
    <div className="loading">
      <div className="loader"></div>
    </div>
  );
}
